
let words = ["The", "Red", "Horse"]

let sentence = reduceFunc(words, (acc, i) => `${acc} ${i}`)
console.log(sentence)

function reduceFunc(arr, callback) {
    let result = arr.shift()
 
    for (const elem of arr)
        result = callback(result, elem)

    return result
}