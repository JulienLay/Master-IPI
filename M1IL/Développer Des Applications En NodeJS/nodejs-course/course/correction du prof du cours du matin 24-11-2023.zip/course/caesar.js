let text = 'Hello!!!'

function caesar(text, key=1) {
    let result = ''

    for(let i = 0 ;  i < text.length ; i++) {
        let currentCharCode = text.charCodeAt(i)

        // Case: lowercase
        if (currentCharCode >= 97 && currentCharCode <= 122) {
            if((currentCharCode + key) > 122)
                result += String.fromCharCode(97 + ((currentCharCode + key) - 123))
            else
                result += String.fromCharCode(currentCharCode + key)

            continue
        }

        // Case: uppercase
        if (currentCharCode >= 65 && currentCharCode <= 90) {
            if((currentCharCode + key) > 90)
                result += String.fromCharCode(65 + ((currentCharCode + key) - 91))
            else
                result += String.fromCharCode(currentCharCode + key)

            continue
        }

        result += String.fromCharCode(currentCharCode)
    }

    return result
}

console.log(caesar(text))