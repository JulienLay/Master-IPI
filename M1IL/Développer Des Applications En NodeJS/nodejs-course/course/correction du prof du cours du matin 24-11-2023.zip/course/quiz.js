const { rejects } = require('assert')
const ReadLine = require('readline')

const rl = ReadLine.createInterface({
    input: process.stdin,
    output: process.stdout
})

const askFirstName = () => {
    return new Promise(resolve => {
        rl.question('Quel est ton prénom ? ', resolve)
    })
}

const askLastName = () => {
    return new Promise(resolve => {
        rl.question('Quel est ton nom ? ', resolve)
    })
}

const askAge = () => {
    return new Promise(resolve => {
        rl.question('Quel âge as-tu ? ', resolve)
    })
}

const askSport = () => {
    return new Promise((resolve) => {
        rl.question('Quel sport pratiques-tu ? ', resolve)
    })
}

const main = () => {
    askFirstName()
        .then(firstName => { console.log(`Ton prénom est ${firstName}`) })
        .catch()
        .then(() => askLastName())
        .then(lastName => { console.log(`Ton nom est ${lastName}`)})
        .then(() => askAge())
        .then(age => { console.log(`Tu as ${age}`) })
        .then(() => askSport())
        .then(sport => {
            console.log(`Tu pratiques le sport ${sport}`)
            rl.close()
        })
}

main()
