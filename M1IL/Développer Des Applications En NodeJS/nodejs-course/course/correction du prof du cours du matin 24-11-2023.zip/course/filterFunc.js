
let marks = [9, 15, 7, 18]
let marksAboveAvg = filterFunc(marks, (mark) => mark < 10 )
console.log(marksAboveAvg)

function filterFunc(arr, callback) {
    let result = []
    for (let elem of arr)
        if (callback(elem)) result.push(elem)

    return result
}