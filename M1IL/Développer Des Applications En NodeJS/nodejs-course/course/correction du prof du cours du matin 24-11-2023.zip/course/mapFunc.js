let marks = [9, 15, 7, 18]

let marksBonus = map(marks, (mark) => { return mark + 1 })
console.log(marksBonus)

function map(arr, callback) {
    let result = []
    for(const element of arr) {
        result.push(callback(element))
    }

    return result
}

